<?php

namespace BetoCampoy\CoraSdk\Exception;

class CoraException extends \RuntimeException {}
