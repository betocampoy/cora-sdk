<?php

namespace BetoCampoy\CoraSdk\Exception;

use BetoCampoy\CoraSdk\Exception\CoraException;

class TransportException extends CoraException {}
